# Proyek Analisis Data: E-Commerce Dataset

Link Streamlit Cloud: [E-Commerce Dashboard by Reynard](https://reynard-ecomdashboard.streamlit.app/)

## Screenshot Dashboard
<img src="dashboardss.png">

## Setup Project


## Reference
[Brazilian E-Commerce Public Dataset](https://drive.google.com/file/d/1MsAjPM7oKtVfJL_wRp1qmCajtSG1mdcK/view?usp=sharing)
